package com.drools.app.beans.controller;

import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.drools.app.beans.Subscribe;

/**
 * @author rahuldigambart
 *
 */
@RestController
public class OfferSubscribeResource {
	static final org.slf4j.Logger logger = LoggerFactory.getLogger(OfferSubscribeResource.class);
	@Autowired
	private KieContainer kieContainer;

	@PostMapping("/products/subscriptions")
	public Subscribe offerSync(@RequestBody Subscribe clientSubscribe) {
		logger.info("Client request to Subscribe for Amazon offers   : " + clientSubscribe.toString());
		// StatelessKieSession session =kieContainer.newStatelessKieSession();
		// "ksessionAmazonOffer" which is defined inside kmodule.xml
		KieSession ksession = kieContainer.newKieSession("ksessionAmazonOffer");
		// Stateful session
		ksession.insert(clientSubscribe);
		// Storage the facts into working memory
		ksession.fireAllRules();
		// Execution of rules using rule engine
		logger.info("Client Subscribed for Amazon offers if Sync flag is true  : " + clientSubscribe.toString());
		return clientSubscribe;

	}

}
